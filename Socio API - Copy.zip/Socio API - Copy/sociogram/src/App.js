import React, {Component} from 'react';
import { Button } from 'reactstrap';
import {Table} from 'reactstrap';
import {Modal, ModalBody, ModalFooter, ModalHeader, FormGroup, Label, Input} from 'reactstrap';
import axios from 'axios';

class App extends Component {
  state = {
    Residents: [],
    newResidentData: {
      name: '',
      color: '',
      room: '',
      major: '',
      involvement: '',
      description: ''
    },
    editResidentData: {
      id: '',
      name: '',
      color: '',
      involvement: '',
      major: '',
      room: '',
      description: ''
    },
    
    newResidentModal: false,
    editResidentModal: false
    
  }
  componentWillMount() {
    this._refreshResidents();
  }
  toggleNewResidentModal() {
    this.setState({
      newResidentModal: !this.state.newResidentModal
    });
  }
  toggleEditResidentModal() {
    this.setState({
      editResidentModal: !this.state.editResidentModal
    });
  }
  addResident() {
    axios.post('http://localhost:8080/api/Residents?access_token=KR6YX0YQy1smDisvpasGJMdkvRIZng12u8V1r7CzcQnsUqeJm7YWkCdRHI7xZwn6', this.state.newResidentData).then((response) => {
      let { Residents } = this.state;
      Residents.push(response.data);
      this.setState({ Residents, newResidentModal: false, newResidentData: {
        name: '',
        color: '',
        room: '',
        major: '',
        involvement: '',
        description: ''
      }});
      
    });
  }
  updateResident() {
    let {name, color, involvement, major, room, description} = this.state.editResidentData;
    axios.put('http://localhost:8080/api/Residents/' + this.state.editResidentData.id, {
      name, color, involvement, major, room, description
    }).then((response) => {
      console.log(response.data);
      this._refreshResidents();
      this.setState({
        editResidentModal: false, editResidentData: { id: '', name: '', color: '', involvement: '', major: '', room: '', description: ''}
      })
      
    });
  }
  editResident(id, name, color, involvement, major, room, description) {
    this.setState({
      editResidentData: {  id, name, color, involvement, major, room, description }, editResidentModal: ! this.state.editResidentModal
    });

  }
  deleteResident(id) {
    console.log('We are trying to delete!');
    console.log(id);
    console.log('http://localhost:8080/api/Residents/' + id);
    axios.delete('http://localhost:8080/api/Residents/' + id).then((response) =>{
      console.log(response);
    this._refreshResidents();
    });
  }
  _refreshResidents() {
    console.log('Made it to refresh!');
    axios.get('http://localhost:8080/api/Residents/').then((response) => {
      this.setState({
        Residents: response.data
      })
    });
  }
  render() {
    let Residents = this.state.Residents.map((Residents) => {
      return (
        <tr key = {Residents.id}>
            <td>{Residents.name}</td>
            <td>{Residents.color}</td>
            <td>{Residents.room}</td>
            <td>{Residents.major}</td>
            <td>{Residents.involvement}</td> 
            <td>{Residents.description}</td> 
            <Button color = "success" size = "sm" className = "my-3 mr-2" onClick = {this.editResident.bind(
              this, Residents.id, Residents.name, Residents.color, Residents.involvement, Residents.major, Residents.room, Residents.description)}>Edit</Button> 
            <Button color = "danger" size = "sm" onClick= {this.deleteResident.bind(this, Residents.id)}>Delete</Button> 
          </tr>
      )
      
    })
  return (
    <div className="App container">

      <h1>Sociogram</h1> 
      <Button className = "my-3" color="primary" onClick={this.toggleNewResidentModal.bind(this)}>Add Resident</Button>
        <Modal isOpen={this.state.newResidentModal} toggle= {this.toggleNewResidentModal.bind(this)} >
          <ModalHeader toggle={this.toggleNewResidentModal.bind(this)}>Add another resident</ModalHeader>
          <ModalBody>
          <FormGroup>
            <Label for = "name">Name</Label>
            <Input id = "name" value = {this.state.newResidentData.name} onChange = {(e) => {
              let {newResidentData} = this.state;
              newResidentData.name = e.target.value;
              this.setState({newResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "color">Color</Label>
            <Input id = "color" value = {this.state.newResidentData.color} onChange = {(e) => {
              let {newResidentData} = this.state;
              newResidentData.color = e.target.value;
              this.setState({newResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "room">Room Number</Label>
            <Input id = "room" value = {this.state.newResidentData.room} onChange = {(e) => {
              let {newResidentData} = this.state;
              newResidentData.room = e.target.value;
              this.setState({newResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "major">Major</Label>
            <Input id = "major" value = {this.state.newResidentData.major} onChange = {(e) => {
              let {newResidentData} = this.state;
              newResidentData.major = e.target.value;
              this.setState({newResidentData});
            }}/>
          </FormGroup>
            <FormGroup>
            <Label for = "involvement">Involvement</Label>
            <Input id = "involvement" value = {this.state.newResidentData.involvement} onChange = {(e) => {
              let {newResidentData} = this.state;
              newResidentData.involvement = e.target.value;
              this.setState({newResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "description">Description</Label>
            <Input id = "description" value = {this.state.newResidentData.description} onChange = {(e) => {
              let {newResidentData} = this.state;
              newResidentData.description = e.target.value;
              this.setState({newResidentData});
            }}/>
          </FormGroup>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.addResident.bind(this)}>Add Resident</Button>{' '}
            <Button color="secondary" onClick={this.toggleNewResidentModal.bind(this)}>Cancel</Button>
          </ModalFooter>
        </Modal>



        <Modal isOpen={this.state.editResidentModal} toggle= {this.toggleEditResidentModal.bind(this)} >
          <ModalHeader toggle={this.toggleEditResidentModal.bind(this)}>Edit resident</ModalHeader>
          <ModalBody>
          <FormGroup>
            <Label for = "name">Name</Label>
            <Input id = "name" value = {this.state.editResidentData.name} onChange = {(e) => {
              let {editResidentData} = this.state;
              editResidentData.name = e.target.value;
              this.setState({editResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "color">Color</Label>
            <Input id = "color" value = {this.state.editResidentData.color} onChange = {(e) => {
              let {editResidentData} = this.state;
              editResidentData.color = e.target.value;
              this.setState({editResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "involvement">Involvement</Label>
            <Input id = "involvement" value = {this.state.editResidentData.involvement} onChange = {(e) => {
              let {editResidentData} = this.state;
              editResidentData.involvement = e.target.value;
              this.setState({editResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "major">Major</Label>
            <Input id = "major" value = {this.state.editResidentData.major} onChange = {(e) => {
              let {editResidentData} = this.state;
              editResidentData.major = e.target.value;
              this.setState({editResidentData});
            }}/>
          </FormGroup>
            <FormGroup>
            <Label for = "room">Room</Label>
            <Input id = "room" value = {this.state.editResidentData.room} onChange = {(e) => {
              let {editResidentData} = this.state;
              editResidentData.room = e.target.value;
              this.setState({editResidentData});
            }}/>
          </FormGroup>
          <FormGroup>
            <Label for = "description">Description</Label>
            <Input id = "description" value = {this.state.editResidentData.description} onChange = {(e) => {
              let {editResidentData} = this.state;
              editResidentData.description = e.target.value;
              this.setState({editResidentData});
            }}/>
          </FormGroup>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.updateResident.bind(this)}>Update Resident</Button>{' '}
            <Button color="secondary" onClick={this.toggleEditResidentModal.bind(this)}>Cancel</Button>
          </ModalFooter>
        </Modal>
      <Table> 
        <thead>
          <tr>
            <th>Name</th>
            <th>Color</th>
            <th>Room Number</th>
            <th>Major</th>
            <th>Involvement</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {Residents}
        </tbody>
      </Table>
    </div>
  );
}
}

export default App;
