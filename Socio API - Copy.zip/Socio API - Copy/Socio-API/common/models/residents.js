'use strict';

module.exports = function(Residents) {

};
